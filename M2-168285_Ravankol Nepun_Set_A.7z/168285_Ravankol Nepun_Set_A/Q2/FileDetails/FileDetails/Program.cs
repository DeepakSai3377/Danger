﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

/*
 * Program demonstrating retriving file Information
 */
namespace FileDetails
{


    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                //absolute-----absolute-whole path,
                //string str1 = @"C:\Users\nravanko\Desktop\168285_Ravankol Nepun_Set_A\Q1\HMS_DAL.cs"";

                //relative-file exists in current file,

                //absolute-----absolute-whole path,
                //FileInfo fileObj1 = new FileInfo(@"C:\Users\nravanko\Desktop\168285_Ravankol Nepun_Set_A\Q1\BS3VehicleManagement\BS3VehicleManagement.DAL\HMS_DAL.cs");


                //relative-file exists in current file,
                FileInfo fileObj = new FileInfo(@"C:\Users\nravanko\Desktop\168285_Ravankol Nepun_Set_A\Q1\BS3VehicleManagement\BS3VehicleManagement.DAL\HMS_DAL.cs");
                if (fileObj.Exists)
                {
                    Console.WriteLine("File Name = {0}", fileObj.Name);
                    Console.WriteLine("File length in Bytes = {0}", fileObj.Length);
                    Console.WriteLine("File Extension = {0}", fileObj.Extension);
                    Console.WriteLine("File Full path = {0}", fileObj.FullName);
                    Console.WriteLine("File Directory = {0}", fileObj.DirectoryName);
                    Console.WriteLine("File Parent Directory = {0}", fileObj.Directory);
                    Console.WriteLine("File Creation Date and Time = {0}", fileObj.CreationTime.ToString("dd-MM-yyyy hh:mm:ss tt"));
                    Console.WriteLine("File Modified Date and Time = {0}", fileObj.LastWriteTime.ToString("dd-MM-yyyy hh:mm:ss tt"));
                    Console.WriteLine("File Last Access Date and Time = {0}", fileObj.LastAccessTime.ToString("dd-MM-yyyy hh:mm:ss tt"));
                    Console.WriteLine("File Attributes = {0}", fileObj.Attributes.ToString());
                }
                else
                {
                    Console.WriteLine("File does not Exists");
                }
            }
            catch (IOException ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.ReadKey();
        }
    }
}




