﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Q3
{
    class Program
    {
        static void Main(string[] args)
        {

            Type t = typeof(Invoice);

            MethodInfo[] mi = t.GetMethods();

            PropertyInfo[] property = t.GetProperties();

            Console.WriteLine("**********Methods Information**********" + Environment.NewLine);

                foreach (MethodInfo m in mi)
                {

                    Console.WriteLine("Method Name : " + m.Name);

                    Console.WriteLine("Method Module : " + m.IsPrivate);

                    Console.WriteLine("Method Module : " + m.IsPublic);

                    Console.WriteLine("Method Module : " + m.IsStatic);

                    Console.WriteLine("Method Module : " + m.IsConstructor);

                    Console.WriteLine("Method Module : " + m.ReturnType);

                    Console.WriteLine("Method Module : " + m.GetParameters());

                    Console.WriteLine("Method ReflectedType : " + m.ReflectedType + Environment.NewLine);

                }

            Console.WriteLine("**********Properties Information**********" + Environment.NewLine);
            foreach (PropertyInfo p in property)
            {
                Console.WriteLine("Prop Name : " + p.Name);

                Console.WriteLine("Prop PropertyType : " + p.PropertyType);

                Console.WriteLine("Prop PropertyType : " + p.CanRead);

                Console.WriteLine("Prop PropertyType : " + p.CanWrite);

                Console.WriteLine("Prop Module : " + p.Module + Environment.NewLine);


            }

            Console.ReadKey();
        }


           
    }
}

