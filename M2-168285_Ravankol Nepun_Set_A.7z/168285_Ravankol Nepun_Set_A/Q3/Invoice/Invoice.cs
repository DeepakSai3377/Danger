﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q3
{
    class Invoice
    {

        //Defining Field


        //Defining AutoImplemented Property

        public string InvoiceId { get; set; }

        public string ProductName { get; set; }

        public double UnitPrice { get; set; }

        public int Quantity { get; set; }

        public double AmountPayable { get; set; }

        //Defining AutoImplemented Property

        public void CalculateAmount()
        {
            AmountPayable = UnitPrice * Quantity;
        }

    }
}
