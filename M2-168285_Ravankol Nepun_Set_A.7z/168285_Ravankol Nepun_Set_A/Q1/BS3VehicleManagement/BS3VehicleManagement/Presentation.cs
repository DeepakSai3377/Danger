﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BS3VehicleManagement.BAL;
using BS3VehicleManagement.Entities;
using BS3VehicleManagement.Exceptions;

namespace BS3VehicleManagement
{
    class Presentation
    {

        /// <summary>
        /// Purpose: This class is used for the working functionalities and also the main function, from which, the user will input data and run the whole program, to store, retrieve and save in file and fetch from file.
        /// Author Name: Ravankol Nepun
        /// Created On: 24/1/2019





        public static void AddVehicle()
        {
            try
            {
                //Creating object of Customer class to access the values being stored through the properties
                HMS_Entities NewVehicle = new HMS_Entities();

                //User Inputs
                Console.Write("Enter Model No : ");
                NewVehicle.ModelNo = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter Vehicle Type: (1- Two Wheeler, 2- Four Wheeler ");
                NewVehicle.TypeOfVehicle = (VehicleType)Enum.Parse(typeof(VehicleType), Console.ReadLine());
                Console.Write("Enter Chasis No  : ");
                NewVehicle.ChasisNo = Console.ReadLine();
                Console.Write("Enter chasis No ");
                Console.Write("Chasis No should be 8 digits ");
                NewVehicle.EngineNo = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter Vendor Name: ");
                NewVehicle.VendorName = Console.ReadLine();
                Console.Write("Enter city you purchased ");
                NewVehicle.City = Console.ReadLine();
                Console.Write("Enter No of Vehicles : ");
                Console.Write("number of vehicles should not be negative");
                NewVehicle.NoOfVehicles = Convert.ToInt32(Console.ReadLine());


                //Checking if all validations by calling the CustomerBL class to use it's function AND using are true AND using NAMED ARGUMENTS
                bool vehicleAdded = HMS_BAL.AddVehicles(NewVehicle);
                if (vehicleAdded == true)
                    Console.WriteLine("Vehicle Added Successfully!");
                else
                    throw new HMS_Exceptions("Vehicle not added!  follow the validations mentioned!");
                HMS_BAL.SerializeData();
            }
            //Catching user defined exception
            catch (HMS_Exceptions p)
            {
                Console.WriteLine(p.Message);
            }

            //Catching System exception
            catch (SystemException e)
            {
                Console.WriteLine(e.Message);
            }
        }
        public static void SearchVehicle()
        {
            int ModelNo;
            HMS_Entities searchedVehicles;

            try
            {
                Console.Write("Enter  Model No for search : ");
                ModelNo = Convert.ToInt32(Console.ReadLine());

                //Checking if all validations by calling the customerBiz class to use it's function AND using are true AND using NAMED ARGUMENTS
                searchedVehicles = HMS_BAL.SearchVehicles(ModelNo: ModelNo);

                if (searchedVehicles != null)
                {
                    Console.WriteLine("Model No : " + searchedVehicles.ModelNo);
                    Console.Write("Model number should be in Numbers");
                    Console.WriteLine("Chasis No : " + searchedVehicles.ChasisNo);
                    Console.Write("Chasis number should be 8 digits ");
                    Console.WriteLine("Type Of vehicle: " + searchedVehicles.TypeOfVehicle);
                    Console.Write("type should be 1  or 2 ");
                    Console.WriteLine("Vendor Name: " + searchedVehicles.VendorName);
                    Console.WriteLine("City: " + searchedVehicles.City);

                }
                else
                {
                    throw new HMS_Exceptions("Vehicle not found!");
                }
            }
            //Catching User defined exception
            catch (HMS_Exceptions p)
            {
                Console.WriteLine(p.Message);
            }
            //Catching System exception
            catch (SystemException e)
            {
                Console.WriteLine(e.Message);
            }
        }
        public static void PrintMenu()
        {
            Console.WriteLine();  
            Console.WriteLine("*************WELCOME TO Honda Motor Corp*************");
            Console.WriteLine("1.  Add Vehicle");
            Console.WriteLine("2.  Search Vehicle");
            Console.WriteLine("3.  Exit");
            Console.WriteLine("**************************************");
        }
        static void Main(string[] args)
        {
            int choice;

           


            do
            {
                //Calling PrintMenu() function to print menu
                PrintMenu();

                bool validchoice;
                Console.Write("Enter your choice please : ");
                validchoice = Int32.TryParse(Console.ReadLine(), out choice);

                //Switch case to allow the user choose the option as per choice
                if (!validchoice)
                    Console.WriteLine("Enter the Choice from 1-3");
                else
                {
                    switch (choice)
                    {
                        case 1:
                            AddVehicle();
                            break;

                        case 2:
                            SearchVehicle();
                            break;
                        case 3: return;
                        default:
                            Console.WriteLine("Invalid Choice!");
                            break;
                    }
                    //While loop to ensure the program runs as per user's choice, unit he/she presses exit
                }
            } while (choice != 4);
        }
    }
}
