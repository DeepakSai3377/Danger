﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace BS3VehicleManagement.Entities
{
    public enum VehicleType
    {
        TwoWheeler = 1, FourWheeler = 2
    }
    [Serializable]
    public class HMS_Entities
    { // Auto Implimented Peopertis
        public int ModelNo { get; set; }
        public string ChasisNo { get; set; }
        public int EngineNo { get; set; }
        public string VendorName { get; set; }
        public string City { get; set; }
        public int NoOfVehicles { get; set; }
        public VehicleType TypeOfVehicle { get; set; }

    }
}