﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

using BS3VehicleManagement.Entities;
using BS3VehicleManagement.Exceptions;
using System.Runtime.Serialization.Formatters.Binary;

namespace BS3VehicleManagement.DAL
{
    public class HMS_DAL
    {
        public static List<HMS_Entities> HMS = new List<HMS_Entities>();

        public static bool AddVehicle(HMS_Entities ModelNo)
        {
            bool VehicleAdded = false;
            try
            {
                HMS.Add(ModelNo);
                VehicleAdded = true;
            }
            catch (HMS_Exceptions ex)
            {
                throw ex;
            }
            return VehicleAdded;
        }
        public static List<HMS_Entities> ReturnVehicleInformation()
        {
            return HMS;
        }
        public static HMS_Entities SearchVehicle(int ModelNo)
        {
            try
            {

                HMS_Entities SearchedVehicle = null;

                SearchedVehicle = HMS.Find(p => p.ModelNo == ModelNo);//null;

                return SearchedVehicle;
            }
            catch (HMS_Exceptions e)
            {
                throw e;
            }
        }
        public static void SerializeData()
        {
            FileStream FileStream;
            try
            {
                FileStream = new FileStream("Vehicles.dat", FileMode.Create, FileAccess.Write);
                BinaryFormatter formatter = new BinaryFormatter();
                formatter.Serialize(FileStream, HMS);
                FileStream.Close();
            }
            catch (IOException e)
            {
                throw e;
            }

        }
        public static List<HMS_Entities> DeserializeData()
        {
            FileStream stream = new FileStream("Vehicles.dat", FileMode.Open, FileAccess.Read);
            BinaryFormatter formatter = new BinaryFormatter();
            HMS = formatter.Deserialize(stream) as List<HMS_Entities>;
            return HMS;
        }
        public static List<HMS_Entities> DisplayInfoFromFile()
        {
            SerializeData();
            HMS = DeserializeData();
            return HMS;
        }

    }
}
