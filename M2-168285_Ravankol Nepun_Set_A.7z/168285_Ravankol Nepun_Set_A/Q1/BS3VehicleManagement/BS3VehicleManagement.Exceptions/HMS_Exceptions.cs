﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BS3VehicleManagement.Exceptions
{
    public class HMS_Exceptions : Exception
    {

        public HMS_Exceptions()
          : base()
        {
        }

        public HMS_Exceptions(string message)
            : base(message)
        {
        }
        public HMS_Exceptions(string message, System.Exception innerException)
            : base(message, innerException)
        {
        }
    }
}
