﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BS3VehicleManagement.DAL;
using BS3VehicleManagement.Entities;
using BS3VehicleManagement.Exceptions;

namespace BS3VehicleManagement.BAL
{
    public class HMS_BAL
    {
        private static bool ValidateVehicles(HMS_Entities Model)
        {
            StringBuilder sb = new StringBuilder();

            bool ValidVehicle = true;
            if (Model.ModelNo <= 0)
            {
                ValidVehicle = false;
                sb.Append(Environment.NewLine + "Invalid Model NO");
            }
            if ((Model.ChasisNo.Length != 8))
            {
                ValidVehicle = false;
                sb.Append(Environment.NewLine + "Chasis No must be of 8 digits and First Digit Must be 3");
            }
            if (Model.NoOfVehicles <= 0)
            {
                ValidVehicle = false;
                sb.Append(Environment.NewLine + "No of vehicles can't be negative");
            }

            return ValidVehicle;


        }
        public static bool AddVehicles(HMS_Entities NewVehicle)
        {
            bool VehicleAdded = false;
            try
            {
                if (ValidateVehicles(NewVehicle))
                {
                    VehicleAdded = HMS_DAL.AddVehicle(NewVehicle);
                }
            }
            catch (HMS_Exceptions)
            {
                throw;
            }
            catch (System.Exception ex)
            {
                throw ex;
            }
            return VehicleAdded;
        }
        public static HMS_Entities SearchVehicles(int ModelNo)
        {
            HMS_Entities VehicleSearched = null;

            try
            {
                //Searching Customer
                VehicleSearched = HMS_DAL.SearchVehicle(ModelNo);

                //If searched Customer is null raise exception
                if (VehicleSearched == null)
                {
                    throw new HMS_Exceptions("Vehicle Info does not exist!");
                }
            }
            catch (HMS_Exceptions p)
            {
                throw;
            }
            catch (SystemException e)
            {
                Console.WriteLine(e.Message);
            }

            return VehicleSearched;
        }
        public static List<HMS_Entities> ReturnVehicleInfo1()
        {
            return HMS_DAL.ReturnVehicleInformation();
        }
        public static void SerializeData()
        {
            HMS_DAL.SerializeData();
        }
        public static List<HMS_Entities> DisplayFromFile()
        {
            List<HMS_Entities> HMS = HMS_DAL.DisplayInfoFromFile();
            return HMS;
        }

    }
}
