import { Component, OnInit } from '@angular/core';
import  { RegisterPojo } from '../registerpojo';
import { RegisterService } from '../register.service';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { AddvehiclePojo } from '../addvehiclepojo';

@Component({
  selector: 'app-register',
  templateUrl: './addvehicle.component.html',
  styleUrls: ['./addvehicle.component.css']
})
export class AddvehicleComponent implements OnInit {


 
  addvpojo: AddvehiclePojo = new AddvehiclePojo();
  submitted = false;
  constructor(private fb: FormBuilder,private route:Router,private userService: RegisterService) { }
 
  //login:LoginPojo=new LoginPojo();
  //Register:RegisterPojo=new RegisterPojo();
  ngOnInit() {
    
{
  //email:['',[ Validators.required,Validators.pattern('^[a-zA-Z0-9_.+-]+@gmail.com+$')] ],
 // email:['',[ Validators.required,Validators.pattern('^[a-zA-Z0-9_.+-]+@gmail.com+$')] ],
  //password:['',[Validators.required,Validators.maxLength(15),Validators.minLength(6)]],
 // repeatpassword:['',[Validators.required,Validators.maxLength(15),Validators.minLength(6)]],
  //password:['',[ Validators.required,Validators.maxLength(15),Validators.minLength(6),	Validators.pattern('^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])[a-zA-Z0-9]+$')] ],

}
  }

  save() {
    console.log("in save")
    this.userService.addVehicle(this.addvpojo)
      .subscribe(data => console.log(data), error => console.log(error));
    this.addvpojo= new AddvehiclePojo();
   
  }

  onAdd() {
    this.submitted = true;
    console.log("onadd")
    this.save();
   // this.route.navigateByUrl("login")

  }
 
}

