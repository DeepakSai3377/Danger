export class LoginPojo{
  
    name:string;
    email:string;
    password:string;
    phonenumber:number;
}