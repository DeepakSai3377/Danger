import { Component, OnInit } from '@angular/core';
import { FormGroup,  FormBuilder,  Validators } from '@angular/forms';
import { Router } from '@angular/router';
import  { LoginPojo } from './LoginPojo'
import { RegisterService } from '../register.service';
import { Register } from '../register/register';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
title:"Quickr Login Page"
  //loginPojo: LoginPojo;

  constructor(private fb: FormBuilder,private route:Router,private userService: RegisterService) { }
  regForm: FormGroup;

  loginAccount:LoginPojo=new LoginPojo();
  registerAccount:Register=new Register();
  ngOnInit() {
    this.regForm = this.fb.group({
      name: ['', [Validators.required,Validators.maxLength(20),Validators.minLength(3) ]],
      /* email:['',[ Validators.required,Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')] ], */
      email:['',[ Validators.required,Validators.pattern('^[a-zA-Z0-9_.+-]+@gmail.com+$')] ],
      phonenumber:['',[Validators.required,Validators.minLength(10), Validators.maxLength(10),Validators.pattern('[6-9]\\d{9}')]],
      password:['',[ Validators.required,Validators.maxLength(15),Validators.minLength(6),Validators.pattern('^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])[a-zA-Z0-9]+$')] ]
      
   });
  }
  onLogin(){
    console.log("in login() method")
    console.log(this.loginAccount)
      this.userService.validateUser(this.loginAccount)
      .subscribe(data => console.log(data), error => console.log(error));
      //this.loginPojo=new LoginPojo();
      //console.log(this.loginAccount)
  //  this.route.navigateByUrl("register");
     }

}
