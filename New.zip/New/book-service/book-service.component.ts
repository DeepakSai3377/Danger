import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-book-service',
  templateUrl: './book-service.component.html',
  styleUrls: ['./book-service.component.css']
})
export class BookServiceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
