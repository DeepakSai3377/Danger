export class MemberShipPojo
{
    membership:string;
}