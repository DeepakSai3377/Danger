/*
	Author: Ravankol Nepun
	Created On : 09-01-2019
	Filename: ElectricityCharge.html
	Description: calculating Electricity Bill and displaying in alert box
*/

function calculateBill()
{ 
  var customer_number=document.frmElectricityBill.txtConsumeNumber.value;
  var customer_name=document.frmElectricityBill.txtConsumerName.value;
  var no_of_units=document.frmElectricityBill.txtUnitsConsumed.value;
  var totalCost;
  if(no_of_units < 0)
   {
	    alert("Please enter valid Number of units");
   }
   else
   {
	   if(no_of_units<=100) 
	   {
        totalCost=no_of_units*2.96
	   }
       else
	   {
       
        totalCost=(no_of_units*5.56)
	   }
	  var html="<html><head></head><body><table>";
		html+="<tr><td>	Number:</td><td>"+customer_number+"</td></tr>";
		html+="<tr><td>Name:</td><td>"+customer_name+"</td></tr>";
		html+="<tr><td>Name:</td><td>"+no_of_units+"</td></tr>"
		html+="<tr><td>Electricity Charges:</td><td>"+totalCost+"</td></tr>";
		html+="</table></body></html>";
	 alert(html);
   }
	   
}
