/*
	Author: Ravankol Nepun
	Created On : 09-01-2019
	Filename: Queries.sql
	Description: Executing given Queries
*/

use Training_12Dec18_Bangalore


/*--section-3--Q2--*/

/*--Q2--1*/
/*Display course name,room name and location of courses taught by richard jackson*/

select CourseName,RoomNo,Location from  Nepun_168285.Course 
where Faculty_ID in (select Faculty_ID from Nepun_168285.Faculty where Faculty_Name=('RichardJackson'));

/*--Q2--2*/
/*-Display courseId,course name for the courses whose name contains 'windows' in course name*/

select CourseID,CourseName from Nepun_168285.Course 
where CourseName like 'Windows%' 
order by CourseName;


/*--Q2--4*/
/*creste stored procedure to accept courseID and display coursedetails*/

create procedure disp_course_detail
(
	@Course_ID varchar(20)
)
as
begin
	
	select *from Nepun_168285.Course where CourseID=@Course_ID
end

exec  display_course_detail '.NET101'


/*procedute with exception handling*/

alter procedure disp_course_detail
(
	@Course_ID varchar(20)
)
as
begin
    if @Course_ID is null
	begin
		throw 50001,' @Course_ID is required',16
	end
	else

	select *from Nepun_168285.Course where CourseID=@Course_ID                   
end
                                                                                       
begin try
    exec disp_course_detail null                                                /*Try and Catch Block*/
	end try                               
begin catch
	print Error_Number()
	print Error_Message()
end catch


/*procedure with result set*/

exec disp_course_detail  '.NET101' with result sets((CourseID varchar(20),CourseName varchar(20),Location varchar(30),RoomNo varchar(20),Faculty_ID int,StartDate date,EndDate date))








