/*
	Author: Ravankol Nepun
	Created On : 09-01-2019
	Filename: CourseTables.sql
	Description: Creating Course Tables
*/

use Training_12Dec18_Bangalore


/*creating table Course*/

create table Nepun_168285.Course (
CourseID int,                
CourseName varchar(30),
Location varchar(10),
RoomNo varchar(10),
Faculty_ID int CONSTRAINT Fk_faculty_id FOREIGN KEY REFERENCES Nepun_168285.Faculty(Faculty_ID ),    /*/*foreign key as column constraint in order to fetch other records from faculty table*/*/
StartDate Date,
Enddate Date
)


/*inserting into Course table Values-----5 rows as specified */

alter table Nepun_168285.Course alter column CourseID varchar(20)       /*alter table as course id to varchar as it is alphanumeric*/

alter table yamuna_168324.course alter column CourseName varchar(50)   /*alter table as course name to 50 characters its characters are more*/

insert into Nepun_168285.Course values ('.NET101','c#5.0','Banglore','Lab 10',120,'12/Jan/2016','20/Jan/2016')
insert into Nepun_168285.Course values ('.NET105','Windows Presention Foundation','Mumbai','Lab 4',110,'02/Feb/2016','05/Feb/2016')
insert into Nepun_168285.Course values ('.NET102','MVC','Hyderabad','Lab 3',130,'11/Sep/2016','25/Sep/2016')
insert into Nepun_168285.Course values ('.NET107','AngularJS','Pune','Lab 4',140,'21/Apr/2016','09/May/2016')
insert into Nepun_168285.Course values ('.NET104','NodeJS','Noida','Lab 7',150,'07/Dec/2016','25/dec/2016')
