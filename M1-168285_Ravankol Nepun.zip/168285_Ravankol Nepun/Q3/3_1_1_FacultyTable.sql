/*
	Author: Ravankol Nepun
	Created On : 09-01-2019
	Filename: FacultyTables.sql
	Description: creating Faculty Tables 
*/


use Training_12Dec18_Bangalore

/*creating schema*/

create schema Nepun_168285


/*creating table Faculty  with given requirements*/
create table Nepun_168285.Faculty (
Faculty_ID int CONSTRAINT PK_faculty_id PRIMARY KEY,                /*primary key as column constraint in order to be unique*/
Faculty_Name varchar(20),
LoT varchar(30),
Manager_ID int
)


/*inserting into Faculty table Values-----5 rows as specified */

insert into Nepun_168285.Faculty values (110,'RichardJackson','.NET',101)
insert into Nepun_168285.Faculty values (120,'Ivana Teach','.NET',110)
insert into Nepun_168285.Faculty values (130,'Deam Ambrose','.NET',111)
insert into Nepun_168285.Faculty values (140,'Rick Flair','.NET',120)
insert into Nepun_168285.Faculty values (150,'David Warner','.NET',121)

/*creating table Course*/

create table Nepun_168285.Course (
CourseID int,                
CourseName varchar(30),
Location varchar(10),
RoomNo varchar(10),
Faculty_ID int CONSTRAINT Fk_faculty_id FOREIGN KEY REFERENCES Nepun_168285.Faculty(Faculty_ID ),        /*/*foreign key as column constraint in order to fetch other records from faculty table*/*/
StartDate Date,
Enddate Date
)

alter table Nepun_168285.Course alter column CourseID varchar(20)
alter table yamuna_168324.course alter column CourseName varchar(50)
insert into Nepun_168285.Course values ('.NET101','c#5.0','Banglore','Lab 10',120,'12/Jan/2016','20/Jan/2016')
insert into Nepun_168285.Course values ('.NET105','Windows Presention Foundation','Mumbai','Lab 4',110,'02/Feb/2016','05/Feb/2016')
insert into Nepun_168285.Course values ('.NET102','MVC','Hyderabad','Lab 3',130,'11/Sep/2016','25/Sep/2016')
insert into Nepun_168285.Course values ('.NET107','AngularJS','Pune','Lab 4',140,'21/Apr/2016','09/May/2016')
insert into Nepun_168285.Course values ('.NET104','NodeJS','Noida','Lab 7',150,'07/Dec/2016','25/dec/2016')

/*-Display course name,room name and location of courses taught by richard jackson*/

select CourseName,RoomNo,Location from  Nepun_168285.Course 
where Faculty_ID in (select Faculty_ID from Nepun_168285.Faculty where Faculty_Name=('RichardJackson'))


/*-Display courseId,course name for the courses whose name contains 'windows' in course name*/

select CourseID,CourseName from Nepun_168285.Course 
where CourseName like 'Windows%' 
order by CourseName



